import { NgModule, OnInit } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContactsComponent } from './contacts/contacts.component';
import { DataTableComponent } from './data-table/data-table.component';
import { LinkTableComponent } from './link-table/link-table.component';
import { LinksComponent } from './links/links.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';

const routes: Routes = [
  {path:'data-table',component:DataTableComponent},
  {path:'contacts',component:ContactsComponent},
  {path:'link-table',component:LinkTableComponent},
  {path:'links',component:LinksComponent},
  {path:'login',component:LoginComponent},
  {path:'register',component:RegisterComponent},
  {path:'home',component:HomeComponent},
  {path:'about',component:AboutComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule implements OnInit{
  ngOnInit(): void {
  }
  constructor() {}
 }
