import { DataSource } from '@angular/cdk/collections';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { map } from 'rxjs/operators';
import { Observable, of as observableOf, merge } from 'rxjs';

// TODO: Replace this with your own data model type
export interface LinkTableItem {
  id: number;
  name: string;
  link_1: string;
  link_2: string;
}

// TODO: replace this with real data from your application
const EXAMPLE_DATA: LinkTableItem[] = [
  {id: 1,  name: 'AZ',link_1:'AZ@aws.com',link_2:'AZ@azure.com'},
  {id: 2,  name: 'BY',link_1:'BY@aws.com',link_2:'BY@azure.com'},
  {id: 3,  name: 'CX',link_1:'CX@aws.com',link_2:'CX@azure.com'},
  {id: 4,  name: 'DW',link_1:'DW@aws.com',link_2:'DW@azure.com'},
  {id: 5,  name: 'EV',link_1:'EV@aws.com',link_2:'EV@azure.com'},
  {id: 6,  name: 'FU',link_1:'FU@aws.com',link_2:'FU@azure.com'},
];

/**
 * Data source for the LinkTable view. This class should
 * encapsulate all logic for fetching and manipulating the displayed data
 * (including sorting, pagination, and filtering).
 */
export class LinkTableDataSource extends DataSource<LinkTableItem> {
  data: LinkTableItem[] = EXAMPLE_DATA;
  paginator: MatPaginator | undefined;
  sort: MatSort | undefined;

  constructor() {
    super();
  }

  /**
   * Connect this data source to the table. The table will only update when
   * the returned stream emits new items.
   * @returns A stream of the items to be rendered.
   */
  connect(): Observable<LinkTableItem[]> {
    if (this.paginator && this.sort) {
      // Combine everything that affects the rendered data into one update
      // stream for the data-table to consume.
      return merge(observableOf(this.data), this.paginator.page, this.sort.sortChange)
        .pipe(map(() => {
          return this.getPagedData(this.getSortedData([...this.data ]));
        }));
    } else {
      throw Error('Please set the paginator and sort on the data source before connecting.');
    }
  }

  /**
   *  Called when the table is being destroyed. Use this function, to clean up
   * any open connections or free any held resources that were set up during connect.
   */
  disconnect(): void {}

  /**
   * Paginate the data (client-side). If you're using server-side pagination,
   * this would be replaced by requesting the appropriate data from the server.
   */
  private getPagedData(data: LinkTableItem[]): LinkTableItem[] {
    if (this.paginator) {
      const startIndex = this.paginator.pageIndex * this.paginator.pageSize;
      return data.splice(startIndex, this.paginator.pageSize);
    } else {
      return data;
    }
  }

  /**
   * Sort the data (client-side). If you're using server-side sorting,
   * this would be replaced by requesting the appropriate data from the server.
   */
  private getSortedData(data: LinkTableItem[]): LinkTableItem[] {
    if (!this.sort || !this.sort.active || this.sort.direction === '') {
      return data;
    }

    return data.sort((a, b) => {
      const isAsc = this.sort?.direction === 'asc';
      switch (this.sort?.active) {
        case 'id': return compare(+a.id, +b.id, isAsc);
        case 'name': return compare(a.name, b.name, isAsc);
        case 'link_1': return compare(+a.link_1, +b.link_1, isAsc);
        case 'link_2': return compare(a.link_2, b.link_2, isAsc);
        default: return 0;
      }
    });
  }
}

/** Simple sort comparator for example ID/Name columns (for client-side sorting). */
function compare(a: string | number, b: string | number, isAsc: boolean): number {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}
