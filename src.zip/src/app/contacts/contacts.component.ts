import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-contacts',
  templateUrl: './contacts.component.html',
  styleUrls: ['./contacts.component.css']
})
export class ContactsComponent implements OnInit{
  ngOnInit(): void {
  }
  constructor(){}
  contactForm = new FormGroup({
    firstname: new FormControl(""),
    lastname: new FormControl(""),
    position: new FormControl(""),
    assigned_to: new FormControl(""),
    gender: new FormControl(""),
    address_line_1: new FormControl(""),
    address_line_2: new FormControl(""),
    city: new FormControl(""),
    state: new FormControl(""),
    phone: new FormControl(""),
    email: new FormControl(""),
  });
  contactSubmitted(){
    console.log(this.contactForm.value);
  }
    
}
