import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-links',
  templateUrl: './links.component.html',
  styleUrls: ['./links.component.css']
})
export class LinksComponent implements OnInit{
  ngOnInit(): void {
  }
  constructor(){}
  linksForm = new FormGroup({
    emp_id: new FormControl(""),
    name: new FormControl(""),
    link_1: new FormControl(""),
    link_2: new FormControl(""),
  });
  linksSubmitted(){
    console.log(this.linksForm.value);
  }
}
