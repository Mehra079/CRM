import { DataSource } from '@angular/cdk/collections';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { map } from 'rxjs/operators';
import { Observable, of as observableOf, merge } from 'rxjs';

// TODO: Replace this with your own data model type
export interface DataTableItem {
  id: number;
  firstname: string;
  lastname: string;
  position: string;
  assigned_to: string;
  gender: string;
  address_line_1: string;
  address_line_2: string;
  city: string;
  state:string,
  phone:number,
  email:string,
}

// TODO: replace this with real data from your application
const EXAMPLE_DATA: DataTableItem[] = [
  {id: 1,  firstname: 'A',lastname:'Z',position:'Systems Engineer',assigned_to:'B',gender:'Male',
  address_line_1:'New city 1',address_line_2:'Old city 6', city:'Ajmer',state:'Rajasthan',
  phone:8942684684,email:'a@gmail.com'},
  {id: 2,  firstname: 'B',lastname:'Y',position:'Data Science Engineer',assigned_to:'C',gender:'Female',
  address_line_1:'New city 2',address_line_2:'Old city 5', city:'Jaipur',state:'Rajasthan',
  phone:8942684685,email:'b@gmail.com'},
  {id: 3,  firstname: 'C',lastname:'X',position:'Data Science Engineer',assigned_to:'D',gender:'Male',
  address_line_1:'New city 3',address_line_2:'Old city 4', city:'Delhi',state:'Delhi',
  phone:8942684686,email:'c@gmail.com'},
  {id: 4,  firstname: 'D',lastname:'W',position:'Systems Engineer',assigned_to:'E',gender:'Male',
  address_line_1:'New city 4',address_line_2:'Old city 3', city:'Mumbai',state:'Maharashtra',
  phone:8942684687,email:'d@gmail.com'},
  {id: 5,  firstname: 'E',lastname:'V',position:'Pipeline Engineer',assigned_to:'F',gender:'FeMale',
  address_line_1:'New city 5',address_line_2:'Old city 2', city:'Banglore',state:'Karnataka',
  phone:8942684688,email:'e@gmail.com'},
  {id: 6,  firstname: 'F',lastname:'U',position:'Systems Engineer',assigned_to:'G',gender:'Male',
  address_line_1:'New city 6',address_line_2:'Old city 1', city:'Indore',state:'Madhya Pradesh',
  phone:8942684689,email:'f@gmail.com'},
];

/**
 * Data source for the DataTable view. This class should
 * encapsulate all logic for fetching and manipulating the displayed data
 * (including sorting, pagination, and filtering).
 */
export class DataTableDataSource extends DataSource<DataTableItem> {
  data: DataTableItem[] = EXAMPLE_DATA;
  paginator: MatPaginator | undefined;
  sort: MatSort | undefined;

  constructor() {
    super();
  }

  /**
   * Connect this data source to the table. The table will only update when
   * the returned stream emits new items.
   * @returns A stream of the items to be rendered.
   */
  connect(): Observable<DataTableItem[]> {
    if (this.paginator && this.sort) {
      // Combine everything that affects the rendered data into one update
      // stream for the data-table to consume.
      return merge(observableOf(this.data), this.paginator.page, this.sort.sortChange)
        .pipe(map(() => {
          return this.getPagedData(this.getSortedData([...this.data ]));
        }));
    } else {
      throw Error('Please set the paginator and sort on the data source before connecting.');
    }
  }

  /**
   *  Called when the table is being destroyed. Use this function, to clean up
   * any open connections or free any held resources that were set up during connect.
   */
  disconnect(): void {}

  /**
   * Paginate the data (client-side). If you're using server-side pagination,
   * this would be replaced by requesting the appropriate data from the server.
   */
  private getPagedData(data: DataTableItem[]): DataTableItem[] {
    if (this.paginator) {
      const startIndex = this.paginator.pageIndex * this.paginator.pageSize;
      return data.splice(startIndex, this.paginator.pageSize);
    } else {
      return data;
    }
  }

  /**
   * Sort the data (client-side). If you're using server-side sorting,
   * this would be replaced by requesting the appropriate data from the server.
   */
  private getSortedData(data: DataTableItem[]): DataTableItem[] {
    if (!this.sort || !this.sort.active || this.sort.direction === '') {
      return data;
    }

    return data.sort((a, b) => {
      const isAsc = this.sort?.direction === 'asc';
      switch (this.sort?.active) {
        case 'id': return compare(+a.id, +b.id, isAsc);
        case 'firstname': return compare(a.firstname, b.firstname, isAsc);
        case 'lastname': return compare(a.lastname, b.lastname, isAsc);
        case 'position': return compare(a.position, b.position, isAsc);
        case 'assigned_to': return compare(a.assigned_to, b.assigned_to, isAsc);
        case 'gender': return compare(a.gender, b.gender, isAsc);
        case 'address_line_1': return compare(a.address_line_1, b.address_line_1, isAsc);
        case 'address_line_2': return compare(a.address_line_2, b.address_line_2, isAsc);
        case 'city': return compare(a.city, b.city, isAsc);
        case 'state': return compare(+a.state, +b.state, isAsc);
        case 'phone': return compare(a.phone, b.phone, isAsc);
        case 'email': return compare(a.email, b.email, isAsc);
        default: return 0;
      }
    });
  }
}

/** Simple sort comparator for example ID/Name columns (for client-side sorting). */
function compare(a: string | number, b: string | number, isAsc: boolean): number {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}
